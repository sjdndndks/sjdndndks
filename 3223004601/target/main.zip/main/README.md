# 论文查重系统 (Plagiarism Detection System)

一个基于k-gram和Jaccard相似度的论文查重系统，使用C++实现，支持中英文混合文本的相似度计算。

## 功能特性

- **多语言支持**：支持中文、英文等多种语言的文本处理
- **高效算法**：使用3-gram分片和FNV-1a哈希算法
- **精确计算**：基于Jaccard相似度计算，结果精确到小数点后两位
- **高性能**：优化的内存管理和算法实现
- **跨平台**：支持Windows、Linux、macOS

## 系统要求

- **编译器**：Visual Studio 2017 或更新版本 (Windows)
- **C++标准**：C++14 或更高
- **操作系统**：64-bit Windows 10
- **内存**：建议至少2GB可用内存

## 构建说明

### 使用Visual Studio 2017

1. 打开Visual Studio 2017
2. 选择"打开文件夹"并选择项目根目录
3. Visual Studio会自动检测CMakeLists.txt并配置项目
4. 选择构建配置（Debug/Release）
5. 构建解决方案

### 使用命令行

```bash
# 创建构建目录
mkdir build
cd build

# 配置CMake
cmake .. -G "Visual Studio 15 2017 Win64"

# 构建项目
cmake --build . --config Release
```

## 使用方法

### 基本用法

```bash
plagiarism_detector.exe <原文文件> <抄袭版文件> <答案文件>
```

### 示例

```bash
plagiarism_detector.exe orig.txt plagiarized.txt result.txt
```

## 算法说明

### 文本预处理
1. **UTF-8解码**：将输入文件按UTF-8编码解码为Unicode码点
2. **字符过滤**：只保留字母、数字（转小写）和CJK字符
3. **标点去除**：过滤掉标点符号、空格等无关字符

### 相似度计算
1. **k-gram分片**：将文本分割成3-gram片段
2. **哈希计算**：使用FNV-1a算法计算每个k-gram的哈希值
3. **集合去重**：使用哈希集合存储唯一的k-gram
4. **Jaccard相似度**：计算两个集合的交集与并集的比值

### 性能优化
- **内存预分配**：使用`reserve()`预分配容器内存
- **哈希集合**：使用`std::unordered_set`提高查找效率
- **优化遍历**：遍历较小的集合以提高交集计算效率

## 测试

### 运行单元测试

```bash
test_main.exe
```

### 运行性能测试

```bash
performance_test.exe
```

### 测试覆盖率

在Debug模式下构建项目后，运行：

```bash
cmake --build . --target coverage
```

## 项目结构

```
c/
├── main.cpp                 # 主程序
├── test_main.cpp           # 单元测试
├── performance_test.cpp    # 性能测试
├── CMakeLists.txt         # CMake构建配置
├── README.md              # 项目说明
├── .gitignore            # Git忽略文件
└── test_data/            # 测试数据
    ├── orig.txt
    ├── orig_0.8_add.txt
    ├── orig_0.8_del.txt
    ├── orig_0.8_dis_1.txt
    ├── orig_0.8_dis_10.txt
    └── orig_0.8_dis_15.txt
```

## 性能指标

基于100万字符的测试数据：

- **文本归一化**：< 100ms
- **k-gram构建**：< 200ms
- **相似度计算**：< 10ms
- **总处理时间**：< 500ms
- **内存使用**：< 50MB

## 测试用例

项目包含10个单元测试用例：

1. **CJK字符识别测试**：验证中文字符正确识别
2. **ASCII字符处理测试**：验证英文字符和数字处理
3. **UTF-8解码测试**：验证多字节字符解码
4. **文本归一化测试**：验证文本预处理功能
5. **哈希函数测试**：验证哈希算法一致性
6. **k-gram集合构建测试**：验证分片和去重功能
7. **Jaccard相似度计算测试**：验证相似度计算准确性
8. **端到端测试**：验证完整处理流程
9. **边界条件测试**：验证空文件和特殊输入处理
10. **性能测试**：验证处理大文件的能力

## 开发规范

### 代码质量
- 遵循C++14标准
- 使用RAII管理资源
- 异常安全保证
- 完整的错误处理

### 性能要求
- 处理时间 < 5秒
- 内存使用 < 2GB
- 支持大文件处理
- 无内存泄漏

### 测试要求
- 单元测试覆盖率 > 90%
- 集成测试通过率 100%
- 性能测试达标
- 边界条件测试完整

